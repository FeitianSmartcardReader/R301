

public class FTPCSCLoader {
	

	//PCSC JNI FUNCTIONS *************************************************************************
	
	private native int SCardEstablishContext(int dwscope, int pvReserved1, int pvReserved2, int phContext);
	
	private native int SCardReleaseContext(int hContext);
	
	private native int SCardListReaders(int phContext, int mszGroups, byte[] szReaders, int pcchReaders);

	private native int SCardConnect(int hContext, byte[] szReaders, int dwShareMode, int dwPreferredProtocols,
					   				int phCard, int pdwActiveProtocols);

	private native int SCardReconnect(int hContext, int dwShareMode, int dwPreferredProtocols, int dwInitialization,
					   				 int pdwActiveProtocols);

	private native int SCardDisconnect(int hCard, int dwDisposition);

	private native int SCardBeginTransaction(int hCard);

	private native int SCardEndTransaction(int hCard, int dwDisposition);

	private native int SCardState(int hCard, int pdwState, int pdwProtocol, byte[] pbATR, int pcbAtrLen);

	private native int SCardGetStatusChange(int hContext, int dwTimeout,  int cReaders, byte [] RdrName,
                    						int UserData, int RdrCurrState, int RdrEventState, int ATRLength,
                    						byte [] pbATR); 
                    						
	private native int SCardStatus(int hCard, byte [] mszReaderNames, int pcchReaderLen, int pdwState,
                      			   int pdwProtocol, byte[] pbATR, int pcbAtrLen);


	private native int SCardTransmit(int hCard, int[] pioSendPci, byte[] pbSendBuffer,
									int cbSendLength, int[] pioRecvPci, byte[] pbRecvBuffer,
									int pcbRecvLength);


	private native int SCardControl(int hCard, int dwControlCode, byte[] lpInBuffer, int nInBufferSize,
								   byte[] lpOutBuffer, int nOutBufferSize, int lpBytesReturned); 

    static {
       System.loadLibrary("FTPCSC");
    }
	
}