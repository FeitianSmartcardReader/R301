include
C:\Program Files\Java\jdk1.6.0_43\include,C:\Program Files\Java\jdk1.6.0_43\include\win32

MyEclipse
C:\Users\lyl\AppData\Local\MyEclipse Professional 2014\binary\com.sun.java.jdk7.win32.x86_1.7.0.u45\bin\java.exe